import { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-transparent text-orange-700 py-6"> {/* Transparent so logo shows through if overlapping */}
      <div className="container mx-auto px-6 flex justify-end items-center"> {/* Only hamburger on right */}

        {/* Desktop Links - Centered or right-aligned */}
        <ul className="hidden lg:flex items-center space-x-8 text-lg font-semibold uppercase">
          <li><Link to="/" className="hover:text-orange-400 transition">Home</Link></li>
          <li><Link to="/about" className="hover:text-orange-400 transition">About</Link></li>
          <li><Link to="/online-store" className="hover:text-orange-400 transition">Online Store</Link></li>
          <li><Link to="/recipes" className="hover:text-orange-400 transition">Recipes</Link></li>
          <li><Link to="/find-store" className="hover:text-orange-400 transition">Find Store</Link></li>
          <li><Link to="/contact-us" className="hover:text-orange-400 transition">Contact Us</Link></li>
        </ul>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="lg:hidden text-4xl focus:outline-none z-50"
        >
          {isOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* Full-Screen Mobile Menu */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-95 z-40 flex flex-col items-center justify-center">
          <ul className="text-center space-y-10 text-3xl font-bold uppercase">
            <li><Link to="/" onClick={() => setIsOpen(false)} className="hover:text-orange-400">Home</Link></li>
            <li><Link to="/about" onClick={() => setIsOpen(false)} className="hover:text-orange-400">About</Link></li>
            <li><Link to="/online-store" onClick={() => setIsOpen(false)} className="hover:text-orange-400">Online Store</Link></li>
            <li><Link to="/recipes" onClick={() => setIsOpen(false)} className="hover:text-orange-400">Recipes</Link></li>
            <li><Link to="/find-store" onClick={() => setIsOpen(false)} className="hover:text-orange-400">Find Store</Link></li>
            <li><Link to="/contact-us" onClick={() => setIsOpen(false)} className="hover:text-orange-400">Contact Us</Link></li>
          </ul>
        </div>
      )}
    </nav>
  );
};

export default Navbar;