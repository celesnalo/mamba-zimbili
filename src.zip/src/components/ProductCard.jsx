const ProductCard = ({ product }) => {
  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden hover:shadow-2xl transition transform hover:-translate-y-2">
      <div className="h-64 bg-gray-200 border-2 border-dashed rounded-t-xl overflow-hidden">
        <img 
          src={product.image || "/assets/placeholder-meat.jpg"} 
          alt={product.name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4">{product.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-3xl font-bold text-red-900">R{product.price}<span className="text-sm font-normal"> /kg</span></span>
          <button className="bg-red-900 hover:bg-red-800 text-white px-6 py-3 rounded-lg font-semibold transition">
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;