import heroimg from '../assets/MambazimbiliButchery/logo.png'
const Hero = () => {
  return (
    <section className="relative h-screen w-full overflow-hidden flex items-center justify-center">
      {/* Background Image - Pick one from suggestions below */}
      <img 
        src={heroimg}// Moody flames & meat (swap with any below)
        alt="Flame-grilled shisanyama perfection"
        className="absolute inset-0 w-full h-full object-cover object-center"
      />

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black bg-opacity-70"></div>

      {/* Hero Copy - Straight from your FB page energy */}
      <div className="relative z-10 text-center text-white px-6 max-w-5xl">
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 drop-shadow-2xl">
          Flame-Grilled. Real Flavour.
        </h1>
        <p className="text-2xl md:text-4xl lg:text-5xl mb-12 font-light drop-shadow-lg">
          Brisket, short ribs, wors, pork, wings, crocodile, kidneys, liver & more!
        </p>
        <p className="text-xl md:text-3xl mb-12 max-w-3xl mx-auto">
          Combos served with uphuthu, chutney & chakalaka.<br />
          Ward 20, Obanjeni — Order early, taste the tradition! 🔥
        </p>

        <div className="space-x-6">
          <a href="/online-store" className="bg-orange-600 hover:bg-orange-500 px-10 py-6 text-2xl font-bold rounded-lg transition inline-block">
            Order Now
          </a>
          <a href="/find-store" className="border-4 border-white hover:bg-white hover:text-black px-10 py-6 text-2xl font-bold rounded-lg transition inline-block">
            Visit Us
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;