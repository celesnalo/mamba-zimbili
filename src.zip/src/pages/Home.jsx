import Hero from '../components/Hero'; // If you have the Hero component, otherwise use inline
import ProductCard from '../components/ProductCard';

const featuredProducts = [
  {
    id: 1,
    name: "Premium Boerewors",
    description: "Traditional spiced South African sausage",
    price: 89.99,
    image: "https://upload.wikimedia.org/wikipedia/commons/c/c6/Boerewors_raw.jpg"
  },
  {
    id: 2,
    name: "Rump Steak",
    description: "Juicy aged beef rump – braai ready",
    price: 149.99,
    image: "https://www.shutterstock.com/shutterstock/photos/333952742/display_1500/stock-photo-fresh-raw-beef-rump-steak-on-crumpled-paper-333952742.jpg"
  },
  {
    id: 3,
    name: "Peri-Peri Chicken Wings",
    description: "Marinated & flame-grilled perfection",
    price: 79.99,
    image: "https://assets.unileversolutions.com/recipes-v3/231301-default.png"
  },
];

const Home = () => {
  return (
    <>
      {/* Hero Section */}
      <Hero/>

      {/* Featured Products */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-red-900 mb-12">
            Featured Cuts 🔥
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Butchery Vibe Section */}
      <section className="py-20">
        <div className="container mx-auto px-6 text-center">
          <img 
            src="https://i.redd.it/d7kwvf33ecf21.jpg" 
            alt="Mamba Zimbili Butchery interior"
            className="mx-auto rounded-2xl shadow-2xl max-w-5xl"
          />
          <p className="text-2xl mt-10 text-gray-700">
            Visit us for the freshest selection in town
          </p>
        </div>
      </section>
    </>
  );
};

export default Home;