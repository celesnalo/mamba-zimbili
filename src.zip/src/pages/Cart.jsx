const Cart = () => {
  // Placeholder — we'll hook up real cart state later
  const isEmpty = true;

  return (
    <div className="container mx-auto py-20 px-6">
      <h1 className="text-5xl md:text-6xl font-bold text-center text-red-900 mb-12">
        Your Cart
      </h1>

      {isEmpty ? (
        <div className="text-center py-20">
          <div className="mx-auto max-w-md mb-10">
            <img 
              src="https://thumbs.dreamstime.com/b/empty-blue-shopping-cart-retail-vector-icon-design-generative-ai-simple-designed-flat-style-perfect-e-commerce-399377875.jpg" 
              alt="Empty cart"
              className="w-full"
            />
          </div>
          <p className="text-2xl text-gray-600 mb-8">Your cart is empty — time to load up on meat! 🔥</p>
          <a href="/online-store" className="bg-orange-500 hover:bg-orange-600 px-10 py-5 text-2xl font-bold rounded-lg text-white transition inline-block">
            Continue Shopping
          </a>
        </div>
      ) : (
        <div> {/* Real cart items will go here */} </div>
      )}
    </div>
  );
};

export default Cart;