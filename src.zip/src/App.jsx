import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import logo from './assets/MambazimbiliButchery/logo.png';
// Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Pages
import Home from './pages/Home';
import About from './pages/About';
import OnlineStore from './pages/OnlineStore';
import FindStore from './pages/FindStore';
import ContactUs from './pages/ContactUs';

function App() {
  return (
    <Router>
      <div className="relative min-h-screen">
        {/* Fixed Logo Only - Adjust position/size here */}
        <div className="fixed top-4 left-4 z-50 pointer-events-none">
          <img 
            src={logo} 
            alt="Mamba Zimbili Butchery" 
            className="h-20 md:h-28 w-auto object-contain drop-shadow-2xl" 
          />
        </div>
        {/*  Navbar */}
        <Navbar />

        {/* Main Content Area */}
        <main className="grow pt-32"> {/* grow = flex-grow, pt-32 = space below navbar */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/online-store" element={<OnlineStore />} />
            <Route path="/find-store" element={<FindStore />} />
            <Route path="/contact-us" element={<ContactUs />} />
            {/*<Route path="/cart" element={<Cart />} />*/}
          </Routes>
        </main>

        {/* Footer stays at bottom */}
        <Footer />
      </div>
    </Router>
  );
}

export default App;